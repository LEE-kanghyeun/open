[개발환경]
OS : MacOS
IDE Tool : PyCharm
Python Version : Python 3.7.4

[실행전 필수 설치 라이브러리]
추가 설치 라이브러리 없음

[실행방법]
python Q2.py "데이터폴더/데이터파일명"
예제) python Q2.py "DataSet/answer.json"

[결과확인]
SGWannabe_Q2.json
예제) {"Q2": [{"original": "나 강아지 산책시키기 하고 싶어.", "new": "나 강아지 산책시키기 하고 싶어."},...]}
